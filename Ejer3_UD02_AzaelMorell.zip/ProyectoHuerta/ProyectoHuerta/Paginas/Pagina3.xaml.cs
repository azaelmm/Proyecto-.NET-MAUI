namespace ProyectoHuerta.Paginas;

public partial class NewPage3 : ContentPage
{
    private string _producte;

    public NewPage3(String producte)
	{
        InitializeComponent();
        _producte = producte;
    }

    private async void OnCounterClicked(object sender, EventArgs e)
    {
        string text = unidadesEntry.Text;
        string unitats = text;
        await Navigation.PushAsync(new Paginas.Pagina4(unitats, _producte));

        
    }

    private async void OnCounterClicked2(object sender, EventArgs e)
    {

        await Navigation.PopAsync();
    }
}