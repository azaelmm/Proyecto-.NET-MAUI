namespace ProyectoHuerta.Paginas;

public partial class Pagina5 : ContentPage
{
	public Pagina5(string producte, string unitats, string adreca)
	{
		InitializeComponent();
        ResumenLabel.Text = $"\n- Producto: {producte}\n- Unidades: {unitats}\n- Direccci�n de envio: {adreca}";
    }

    private async void OnCounterClicked(object sender, EventArgs e)
    {


        await Navigation.PopToRootAsync();

       
    }
}