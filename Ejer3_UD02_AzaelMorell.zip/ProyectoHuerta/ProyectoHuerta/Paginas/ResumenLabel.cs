﻿namespace ProyectoHuerta.Paginas
{
    internal class ResumenLabel
    {
    }
}