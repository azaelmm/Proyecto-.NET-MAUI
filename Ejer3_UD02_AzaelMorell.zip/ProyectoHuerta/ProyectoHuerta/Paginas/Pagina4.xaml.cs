namespace ProyectoHuerta.Paginas;

public partial class Pagina4 : ContentPage
{

    private string _producte;
    private string _unitats;


    public Pagina4(String unidades, String producte)
	{
		InitializeComponent();
        _producte = producte;
        _unitats = unidades;
    }

    private async void OnCounterClicked(object sender, EventArgs e)
    {
        string text = addressEntry.Text;
        var address = text;
        await Navigation.PushAsync(new Paginas.Pagina5(_producte, _unitats, address));


    }

    private async void OnCounterClicked2(object sender, EventArgs e)
    {

        await Navigation.PopAsync();
    }
}