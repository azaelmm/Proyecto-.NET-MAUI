namespace ProyectoHuerta.Paginas;

public partial class NewPage1 : ContentPage
{
	public NewPage1()
	{
		InitializeComponent();
	}

    private async void OnCounterClicked(object sender, EventArgs e)
    {
        string producte = productoEntry.Text;
        await Navigation.PushAsync(new Paginas.NewPage3(producte));

       
    }

    private async void OnCounterClicked2(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }
}