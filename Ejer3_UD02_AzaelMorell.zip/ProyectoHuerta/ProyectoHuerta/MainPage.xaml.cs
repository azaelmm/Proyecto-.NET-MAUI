﻿using ProyectoHuerta.Paginas;

namespace ProyectoHuerta
{
    public partial class MainPage : ContentPage
    {
        int count = 0;
        public MainPage()
        {
           InitializeComponent();
        }

        private async void OnCounterClicked(object sender, EventArgs e)
        {
            /*count++;

            if (count == 1)
            {
                CounterBtn.Text = $"Clicked {count} time";
            }
            else
            {
                CounterBtn.Text = $"Clicked {count} time";
            }*/

            await Navigation.PushAsync(new Paginas.NewPage1());

            // Navigation.PushAsync(new pagina2());
        }

    }

}
